import { CANONICAL_MARINA_BIO } from "./core";

export type RouteType = "identity" | "framework" | "product" | "current" | "operator" | "support";

const frameworks: Record<string, string> = {
  "333": `333 Method: a daily relationship-building system. Canonical execution: 3 meaningful comments, 3 likes, 3 non-salesy messages. Rules: no pitching, no copy-paste DMs, curiosity before conversion. This definition must appear before expansion when the user asks what the method is.`,
  "confidence stacking": `Confidence Stacking Method: confidence is built through kept promises, not mindset work alone. Confidence is a result, not a prerequisite. Small wins stack faster than big intentions. Identity shifts after action is taken. Execution: choose 1 daily non-negotiable action, complete it regardless of mood, track completion, repeat daily, and increase difficulty only after consistency is proven. Do not silently redefine this with Power Identity Activation, receipts work, or the 3-Format Stack.`,
  "seven layers deep": `Seven Layers Deep: Marina's relationship-to-revenue method for DMs and engagement. Start with the surface problem, then ask one honest follow-up at a time to uncover the real block, real desire, and real decision. Prompt style includes: what made you comment that, what have you tried, what's hardest, what happens if nothing changes, what do you want instead, what's stopping you, and what would you want fixed first. Do not send all layers as a scripted interrogation.`,
  "finding your starving market": `Finding Your Starving Market: a starving market has a painful problem, awareness of the problem, urgency to solve it, and language to describe it. Broad equals invisible. Specific equals scalable. You do not create desire, you locate it. Filter: who is she, what does she want badly, what has she tried, why hasn't it worked, what is she afraid to admit.`,
  "hook plus truth plus shift plus cta": `Hook plus Truth plus Shift plus CTA is Marina's short-form structure for Reels. First 3 seconds matter, use one idea per Reel, do not over-explain, and speak like you talk.`,
  "posting for profits": `Posting for Profits: content has one job, start conversations that lead to money. Categories: pain calling, story with lesson, authority teaching, relatable truth, direct CTA. Repeat what works, stop reinventing formats, clarity beats creativity. If engagement exists but DMs do not, adjust the CTA and conversation path.`,
  "power identity activation": `Power Identity Activation: use when the user is unclear, blending in, or hiding. Healed scars, not open wounds. Flow: choose 3 power words, identify the fear attached to each, separate fact from feeling, choose the new feeling, declare the new identity in present tense. Output: brand voice, positioning language, content themes, and offer direction.`,
  "lead slayer": `Lead Slayer logic centers authority-led lead generation, founder positioning, profile clarity, permission-first DMs, lead tracking, weekly presentations, and repeatable sales activity. DMs follow acknowledge, ask, listen, validate, offer next step. Never dump links, lead with price, or rush the conversation.`,
  "social makeover": `Social Makeover profile rules: one clear promise, one clear audience, one clear next step. If someone cannot understand who you help, what you do, and why it matters in about 5 seconds, the profile fails.`,
};

const productContext = `
Product recommendation rules: recommend one primary product at a time. Give a useful action first. Recommend paid support when the user needs structure, systems, accountability, or speed. Never guess current pricing, links, dates, or schedules.
BMOD: for scattered content, weak conversion path, inconsistent visibility, and need for ongoing structure and coaching.
Marina On Demand: daily AI execution support for overthinking, hesitation, and fast direction between coaching sessions.
Posting for Profits: posting consistently but not generating income.
Reel Cash Flow: weak hooks, inconsistent Reels, views not becoming conversations or leads.
Social Makeover: confusing profile, weak bio, unclear positioning, low trust on first impression.
Lead Slayer: no pipeline, no lead list, avoids DMs, inconsistent outreach.
Messy to Millions: fear of visibility, muted messaging, hiding behind perfection, emotionally flat content.
Finding Your Starving Market: unclear niche, wrong audience, broad content, weak demand.
Network Marketing On Demand: generic MLM messaging, compliance fear, script resistance, wants human brand authority.
Brand From Home: business foundation, daily structure, scattered execution.
Paid Ads Training: only after message and conversion path are working.
`.trim();

const operatorContext = `
Marina's diagnostic order is Offer -> Message -> Path -> Volume -> Conversion.
If growth is weak, check clarity. If sales are weak, check the offer and the ask. If consistency is weak, check systems and non-negotiables.
If overwhelmed, cut platforms, content types, frequency, and restore consistency. Complexity is a symptom, not a strategy.
Ads are allowed only when organic content converts, messaging is proven, CTA is clear, and the funnel works manually.
`.trim();

export function classifyAndRetrieve(message: string): { route: RouteType; context: string } {
  const q = message.toLowerCase();

  if (/who is marina|tell me about marina|what does marina simone do/.test(q)) {
    return { route: "identity", context: `Canonical Marina Simone bio:\n${CANONICAL_MARINA_BIO}\nUse this approved bio. Do not replace it with web research unless the user explicitly asks for current public information.` };
  }

  const matches = Object.entries(frameworks).filter(([key]) => q.includes(key));
  if (matches.length) {
    return { route: "framework", context: `CANONICAL METHOD SOURCE. Follow exactly before adding examples.\n\n${matches.map(([,v])=>v).join("\n\n")}` };
  }

  if (/which.*program|which.*product|what.*program|what.*should i buy|recommend.*program|recommend.*product/.test(q)) {
    return { route: "product", context: productContext };
  }

  if (/current price|price.*current|registration.*open|still open|current link|when is|event date|available now|how much/.test(q)) {
    return { route: "current", context: `This request needs verified current business data. Do not use old dates, prices, or links from permanent training. If verified current data is not supplied in this request, clearly say it needs verification instead of guessing.` };
  }

  if (/i feel like a failure|spiral|spiraling|imposter|scared|afraid|confidence|feel ridiculous|don't want to show up/.test(q)) {
    return { route: "support", context: operatorContext };
  }

  return { route: "operator", context: operatorContext };
}
