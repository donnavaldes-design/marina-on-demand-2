import { createClient } from "@/lib/supabase/server";

export async function requireUser() {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getClaims();
  if (error || !data?.claims?.sub) throw new Error("UNAUTHORIZED");
  const email = typeof data.claims.email === "string" ? data.claims.email.toLowerCase() : "";
  const allowed = (process.env.ALLOWED_TEST_EMAILS || "")
    .split(",")
    .map((x) => x.trim().toLowerCase())
    .filter(Boolean);
  if (allowed.length && !allowed.includes(email)) throw new Error("NOT_ALLOWED");
  return { supabase, userId: data.claims.sub as string, email };
}

export async function hasAccess(userId: string) {
  if (process.env.PROTOTYPE_ALLOW_ALL_AUTHENTICATED === "true") return true;

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("entitlements")
    .select("active,renewal_or_expiry")
    .eq("user_id", userId)
    .maybeSingle();

  if (error || !data?.active) return false;
  if (data.renewal_or_expiry && new Date(data.renewal_or_expiry) < new Date()) return false;
  return true;
}
