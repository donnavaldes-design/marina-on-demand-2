# Marina knowledge architecture

Production hierarchy:
1. Marina Core / OS
2. Method Library, canonical named frameworks
3. Product Intelligence, recommendation fit logic
4. User Intent and Demand Map, routing logic
5. Supporting workbooks/transcripts, examples only

The prototype keeps hard framework locks in structured code because Marina 1.0 drifted on 333 Method and Confidence Stacking when retrieval selected adjacent materials. Larger supporting corpora can be moved into OpenAI File Search after the deterministic core passes the benchmark.
