-- Reference schema matching the live Marina On Demand Supabase prototype.
-- The live database was created via the Supabase management connection.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  active boolean not null default false,
  source text check (source in ('monthly','annual','bmod','admin','prototype')),
  plan_name text,
  ghl_contact_id text,
  renewal_or_expiry timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text,
  openai_conversation_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant','system')),
  content text not null,
  model text,
  response_id text,
  usage jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.customer_memory (
  user_id uuid primary key references auth.users(id) on delete cascade,
  business_type text,
  company_or_vehicle text,
  primary_offer text,
  target_audience text,
  primary_goal text,
  current_constraint text,
  current_framework text,
  preferred_platform text,
  last_assignment text,
  last_assignment_status text,
  brand_positioning text,
  important_business_context jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.business_data (
  id uuid primary key default gen_random_uuid(),
  entity_type text not null,
  name text not null,
  status text,
  price numeric,
  currency text default 'USD',
  billing_interval text,
  included_with_bmod boolean,
  start_date date,
  end_date date,
  official_url text,
  verified_at timestamptz,
  notes text,
  metadata jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  unique(entity_type, name)
);

create table if not exists public.knowledge_sources (
  id uuid primary key default gen_random_uuid(),
  source_key text unique not null,
  title text not null,
  category text not null,
  authority text not null,
  source_drive_id text,
  active boolean not null default true,
  version text,
  notes text,
  updated_at timestamptz not null default now()
);

create table if not exists public.ghl_events (
  id uuid primary key default gen_random_uuid(),
  event_type text not null,
  ghl_contact_id text,
  email text,
  payload jsonb not null default '{}'::jsonb,
  processed boolean not null default false,
  created_at timestamptz not null default now(),
  processed_at timestamptz
);
