import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Marina On Demand",
  description: "Your brand and business operator, on demand.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
