"use client";

import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setLoading(true); setError("");
    const supabase = createClient();
    const site = process.env.NEXT_PUBLIC_SITE_URL || window.location.origin;
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${site}/auth/callback` },
    });
    setLoading(false);
    if (error) setError(error.message); else setSent(true);
  }

  return <main className="login-wrap">
    <section className="login-card">
      <div className="brand-serif" style={{color:"var(--marina)",fontWeight:700}}>MARINA</div>
      <h1 className="brand-serif">On Demand</h1>
      <p>Your brand and business operator, ready when you are. Enter the email connected to your membership.</p>
      {sent ? <p><strong>Check your inbox.</strong><br/>Your private sign-in link is on the way.</p> :
      <form onSubmit={submit} style={{display:"grid",gap:12,marginTop:24}}>
        <input className="field" type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" />
        <button className="primary" disabled={loading}>{loading ? "Sending..." : "Send my sign-in link"}</button>
        {error && <div className="error">{error}</div>}
      </form>}
    </section>
  </main>;
}
