import { NextResponse } from "next/server";
import { requireUser } from "@/lib/authz";

export async function GET(_: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const { supabase, userId } = await requireUser();
    const { data: conv } = await supabase.from("conversations").select("id").eq("id",id).eq("user_id",userId).maybeSingle();
    if (!conv) return NextResponse.json({error:"Not found"},{status:404});
    const { data, error } = await supabase.from("messages").select("id,role,content,created_at").eq("conversation_id",id).order("created_at",{ascending:true});
    if (error) throw error;
    return NextResponse.json({messages:data || []});
  } catch (e) {
    return NextResponse.json({error:e instanceof Error?e.message:"ERROR"},{status:500});
  }
}
