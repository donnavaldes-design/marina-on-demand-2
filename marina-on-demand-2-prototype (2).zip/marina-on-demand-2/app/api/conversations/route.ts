import { NextResponse } from "next/server";
import { requireUser, hasAccess } from "@/lib/authz";
import { openai } from "@/lib/openai";

export async function GET() {
  try {
    const { supabase, userId } = await requireUser();
    const { data, error } = await supabase.from("conversations").select("id,title,created_at,updated_at").eq("user_id",userId).order("updated_at",{ascending:false}).limit(40);
    if (error) throw error;
    return NextResponse.json({ conversations: data || [] });
  } catch (e) {
    const m = e instanceof Error ? e.message : "ERROR";
    return NextResponse.json({ error:m }, { status:m==="UNAUTHORIZED"?401:500 });
  }
}

export async function POST() {
  try {
    const { supabase, userId } = await requireUser();
    if (!(await hasAccess(userId))) return NextResponse.json({error:"Access inactive"},{status:403});
    const conv = await openai.conversations.create({ metadata: { app:"marina-on-demand", user_id:userId } });
    const { data, error } = await supabase.from("conversations").insert({ user_id:userId, openai_conversation_id:conv.id, title:"New conversation" }).select("id,title,created_at,updated_at").single();
    if (error) throw error;
    return NextResponse.json({ conversation:data });
  } catch (e) {
    const m=e instanceof Error?e.message:"ERROR";
    return NextResponse.json({error:m},{status:m==="UNAUTHORIZED"?401:500});
  }
}
