import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const allowedSources = new Set(["monthly", "annual", "bmod", "admin"]);

export async function POST(request: Request) {
  const secret = request.headers.get("x-marina-webhook-secret");
  if (!process.env.GHL_WEBHOOK_SECRET || secret !== process.env.GHL_WEBHOOK_SECRET) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const payload = await request.json();
  const email = String(payload.email || payload.contact?.email || "").toLowerCase().trim();
  const active = payload.active === true || String(payload.status || "").toLowerCase() === "active";
  const rawSource = String(payload.source || "bmod").toLowerCase();
  const source = allowedSources.has(rawSource) ? rawSource : "bmod";
  const ghlContactId = String(payload.ghl_contact_id || payload.contact?.id || "").trim() || null;
  const planName = String(payload.plan_name || payload.plan || "").trim() || null;
  const renewalOrExpiry = payload.renewal_or_expiry || payload.expires_at || null;

  if (!email) return NextResponse.json({ error: "email required" }, { status: 400 });

  const admin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false, autoRefreshToken: false } }
  );

  await admin.from("ghl_events").insert({
    event_type: active ? "access_active" : "access_inactive",
    ghl_contact_id: ghlContactId,
    email,
    payload,
  });

  const { data: profile } = await admin.from("profiles").select("id").eq("email", email).maybeSingle();
  if (!profile) {
    return NextResponse.json({
      ok: true,
      note: "No Supabase user yet. GHL remains source of truth; entitlement can sync after first login.",
    });
  }

  const { error } = await admin.from("entitlements").upsert(
    {
      user_id: profile.id,
      active,
      source,
      plan_name: planName,
      ghl_contact_id: ghlContactId,
      renewal_or_expiry: renewalOrExpiry,
      metadata: payload,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "user_id" }
  );
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await admin
    .from("ghl_events")
    .update({ processed: true, processed_at: new Date().toISOString() })
    .eq("email", email)
    .eq("processed", false);

  return NextResponse.json({ ok: true });
}
