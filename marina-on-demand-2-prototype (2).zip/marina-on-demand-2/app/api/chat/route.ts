import { NextResponse } from "next/server";
import { requireUser, hasAccess } from "@/lib/authz";
import { openai } from "@/lib/openai";
import { MARINA_CORE } from "@/lib/marina/core";
import { classifyAndRetrieve } from "@/lib/marina/knowledge";

export async function POST(request: Request) {
  try {
    const { supabase, userId } = await requireUser();
    if (!(await hasAccess(userId))) {
      return NextResponse.json({ error: "Your Marina On Demand access is inactive." }, { status: 403 });
    }

    const body = await request.json();
    const message = String(body.message || "").trim();
    const requestedConversationId = body.conversationId ? String(body.conversationId) : "";
    if (!message) return NextResponse.json({ error: "Message required" }, { status: 400 });

    let dbConv: { id: string; openai_conversation_id: string | null; title: string | null } | null = null;

    if (requestedConversationId) {
      const { data } = await supabase
        .from("conversations")
        .select("id,openai_conversation_id,title")
        .eq("id", requestedConversationId)
        .eq("user_id", userId)
        .maybeSingle();
      dbConv = data;
    }

    if (!dbConv) {
      const oai = await openai.conversations.create({
        metadata: { app: "marina-on-demand", user_id: userId },
      });
      const title = message.length > 58 ? `${message.slice(0, 55)}...` : message;
      const { data, error } = await supabase
        .from("conversations")
        .insert({ user_id: userId, openai_conversation_id: oai.id, title })
        .select("id,openai_conversation_id,title")
        .single();
      if (error || !data) throw error || new Error("Could not create conversation");
      dbConv = data;
    }

    if (!dbConv.openai_conversation_id) throw new Error("Conversation state is missing");

    const { error: userMessageError } = await supabase.from("messages").insert({
      conversation_id: dbConv.id,
      user_id: userId,
      role: "user",
      content: message,
    });
    if (userMessageError) throw userMessageError;

    const { data: memory } = await supabase
      .from("customer_memory")
      .select("business_type,company_or_vehicle,primary_offer,target_audience,primary_goal,current_constraint,current_framework,preferred_platform,last_assignment,last_assignment_status,brand_positioning,important_business_context,updated_at")
      .eq("user_id", userId)
      .maybeSingle();

    const routed = classifyAndRetrieve(message);
    const memoryText = memory
      ? `\nCUSTOMER BUSINESS MEMORY (use only when relevant; the current user message always wins):\n${JSON.stringify(memory)}`
      : "";
    const instructions = `${MARINA_CORE}\n\nROUTED CANONICAL CONTEXT:\n${routed.context}${memoryText}`;

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-terra",
      reasoning: { effort: "medium" },
      conversation: dbConv.openai_conversation_id,
      instructions,
      input: [
        {
          role: "user",
          content: [{ type: "input_text", text: message }],
        },
      ],
    });

    const answer = response.output_text?.trim() || "I hit a blank response. Try that once more.";

    const { error: assistantMessageError } = await supabase.from("messages").insert({
      conversation_id: dbConv.id,
      user_id: userId,
      role: "assistant",
      content: answer,
      model: response.model || process.env.OPENAI_MODEL || "gpt-5.6-terra",
      response_id: response.id,
      usage: response.usage || null,
    });
    if (assistantMessageError) throw assistantMessageError;

    await supabase
      .from("conversations")
      .update({ updated_at: new Date().toISOString() })
      .eq("id", dbConv.id)
      .eq("user_id", userId);

    return NextResponse.json({ answer, conversationId: dbConv.id, route: routed.route });
  } catch (e) {
    const message = e instanceof Error ? e.message : "ERROR";
    const status = message === "UNAUTHORIZED" ? 401 : message === "NOT_ALLOWED" ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
