"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Conv = { id:string; title:string; created_at:string; updated_at:string };
type Msg = { id?:string; role:"user"|"assistant"; content:string; created_at?:string };
const starters = [
  "Rewrite my profile like a Lead Slayer",
  "Create my Seven Layers Deep DM flow",
  "Turn my story into a weekly live",
  "Build my warm lead follow-up plan",
];

export default function ChatShell({email}:{email:string}) {
  const [convs,setConvs]=useState<Conv[]>([]);
  const [active,setActive]=useState<string>("");
  const [messages,setMessages]=useState<Msg[]>([]);
  const [input,setInput]=useState("");
  const [loading,setLoading]=useState(false);
  const [error,setError]=useState("");
  const bottom=useRef<HTMLDivElement>(null);

  useEffect(()=>{ loadConvs(); },[]);
  useEffect(()=>{ bottom.current?.scrollIntoView({behavior:"smooth"}); },[messages,loading]);

  async function loadConvs(){
    const r=await fetch("/api/conversations"); const j=await r.json();
    if(r.ok) setConvs(j.conversations || []);
  }
  async function selectConv(id:string){
    setActive(id); setError("");
    const r=await fetch(`/api/conversations/${id}/messages`); const j=await r.json();
    if(r.ok) setMessages(j.messages || []);
  }
  function newChat(){ setActive(""); setMessages([]); setInput(""); setError(""); }
  async function send(text?:string){
    const value=(text ?? input).trim(); if(!value||loading)return;
    setInput(""); setError(""); setMessages(m=>[...m,{role:"user",content:value}]); setLoading(true);
    const r=await fetch("/api/chat",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({message:value,conversationId:active||undefined})});
    const j=await r.json(); setLoading(false);
    if(!r.ok){ setError(j.error||"Something went wrong"); return; }
    setMessages(m=>[...m,{role:"assistant",content:j.answer}]);
    if(!active) setActive(j.conversationId);
    await loadConvs();
  }
  function submit(e:FormEvent){e.preventDefault();void send();}
  async function signOut(){ const supabase=createClient(); await supabase.auth.signOut(); window.location.href="/login"; }

  return <main className="chat-layout">
    <aside className="sidebar">
      <div className="logo brand-serif">Marina<br/>On Demand<small>Brand. Lead. Convert.</small></div>
      <button className="new-chat" onClick={newChat}>+ New conversation</button>
      <div className="thread-list">{convs.map(c=><button key={c.id} className={`thread ${active===c.id?"active":""}`} onClick={()=>selectConv(c.id)}>{c.title}</button>)}</div>
      <div className="side-footer">{email}<br/><button onClick={signOut} style={{border:0,background:"transparent",padding:0,color:"var(--marina-dark)",cursor:"pointer"}}>Sign out</button></div>
    </aside>
    <section className="chat-main">
      <header className="chat-top"><strong>Marina On Demand 2.0</strong><span>Private prototype</span></header>
      <div className="messages">
        {!messages.length ? <div className="welcome">
          <h2 className="brand-serif">What are we fixing today?</h2>
          <p>Bring me the messy caption, the vague offer, the dead DMs, the Reel that got views but no buyers, or the thing you keep overthinking.</p>
          <div className="quick-grid">{starters.map(s=><button className="quick" key={s} onClick={()=>send(s)}>{s}</button>)}</div>
        </div> : messages.map((m,i)=><div className={`msg ${m.role}`} key={m.id||i}><div className="avatar">{m.role==="assistant"?"M":"YOU"}</div><div className="bubble">{m.content}</div></div>)}
        {loading && <div className="msg"><div className="avatar">M</div><div className="bubble">Thinking...</div></div>}
        <div ref={bottom}/>
      </div>
      <div className="composer-wrap">
        <form className="composer" onSubmit={submit}>
          <textarea value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask Marina..." onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();void send();}}}/>
          <button className="send" type="submit" disabled={loading||!input.trim()}>↑</button>
        </form>
        {error && <div className="error" style={{maxWidth:860,margin:"8px auto 0"}}>{error}</div>}
      </div>
    </section>
  </main>;
}
